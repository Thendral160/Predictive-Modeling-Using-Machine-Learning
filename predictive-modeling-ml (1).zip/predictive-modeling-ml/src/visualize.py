"""
Visualization Module
-----------------------
Generates confusion matrix heatmaps, ROC curve comparisons, and
model performance bar charts, saved into the results/ directory.
"""

import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns


def plot_confusion_matrix(cm, model_name, class_names, out_dir="results"):
    """Save a heatmap confusion matrix for a single model."""
    os.makedirs(out_dir, exist_ok=True)
    plt.figure(figsize=(5, 4))
    sns.heatmap(
        cm,
        annot=True,
        fmt="d",
        cmap="Blues",
        xticklabels=class_names,
        yticklabels=class_names,
    )
    plt.title(f"Confusion Matrix - {model_name}")
    plt.xlabel("Predicted Label")
    plt.ylabel("True Label")
    plt.tight_layout()
    fname = f"confusion_matrix_{model_name.lower().replace(' ', '_')}.png"
    plt.savefig(os.path.join(out_dir, fname), dpi=150)
    plt.close()
    return fname


def plot_roc_curves(results, out_dir="results"):
    """Save a combined ROC curve plot comparing all models."""
    os.makedirs(out_dir, exist_ok=True)
    plt.figure(figsize=(6.5, 5.5))
    for name, data in results.items():
        fpr, tpr = data["roc_data"]
        auc = data["metrics"]["ROC-AUC"]
        plt.plot(fpr, tpr, linewidth=2, label=f"{name} (AUC = {auc:.3f})")
    plt.plot([0, 1], [0, 1], linestyle="--", color="gray", label="Random Guess")
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("ROC Curve Comparison")
    plt.legend(loc="lower right")
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, "roc_curve_comparison.png"), dpi=150)
    plt.close()


def plot_model_comparison(summary_df, out_dir="results"):
    """Save a grouped bar chart comparing metrics across models."""
    os.makedirs(out_dir, exist_ok=True)
    ax = summary_df.plot(kind="bar", figsize=(8.5, 5.5), rot=15, colormap="viridis")
    plt.title("Model Performance Comparison")
    plt.ylabel("Score")
    plt.ylim(0, 1.05)
    plt.legend(loc="lower right")
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, "model_comparison.png"), dpi=150)
    plt.close()
