"""
Data Preprocessing Module
--------------------------
Loads the Breast Cancer Wisconsin (Diagnostic) dataset and prepares it
for model training: train/test split + feature scaling.
"""

import pandas as pd
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler


def load_data():
    """Load the Breast Cancer Wisconsin dataset and return it as a DataFrame.

    Returns:
        df (pd.DataFrame): Feature columns + 'target' column
                            (0 = malignant, 1 = benign).
        target_names (list): Human-readable class labels.
    """
    dataset = load_breast_cancer()
    df = pd.DataFrame(dataset.data, columns=dataset.feature_names)
    df["target"] = dataset.target
    return df, list(dataset.target_names)


def save_raw_data(df, path="data/breast_cancer_data.csv"):
    """Persist the raw dataset to CSV for reference / reproducibility."""
    df.to_csv(path, index=False)
    print(f"Raw dataset saved to {path}")


def split_and_scale(df, test_size=0.2, random_state=42):
    """Split the dataset into train/test sets and apply standard scaling.

    Returns:
        X_train_scaled, X_test_scaled, y_train, y_test, scaler, feature_names
    """
    X = df.drop(columns=["target"])
    y = df["target"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=y
    )

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    return X_train_scaled, X_test_scaled, y_train, y_test, scaler, X.columns.tolist()
