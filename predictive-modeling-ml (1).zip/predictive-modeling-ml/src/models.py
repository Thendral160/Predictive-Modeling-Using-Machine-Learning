"""
Model Definitions & Training Module
-------------------------------------
Defines Logistic Regression, Decision Tree, and Random Forest classifiers
and provides helpers to train and persist them.
"""

import os
import joblib
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier


def get_models():
    """Return a dictionary mapping model name -> initialized estimator."""
    return {
        "Logistic Regression": LogisticRegression(max_iter=5000, random_state=42),
        "Decision Tree": DecisionTreeClassifier(max_depth=5, random_state=42),
        "Random Forest": RandomForestClassifier(
            n_estimators=200, max_depth=8, random_state=42
        ),
    }


def train_models(models, X_train, y_train):
    """Fit every model in `models` on the training data."""
    trained = {}
    for name, model in models.items():
        model.fit(X_train, y_train)
        trained[name] = model
        print(f"Trained: {name}")
    return trained


def save_models(trained_models, out_dir="models"):
    """Save each trained model to disk with joblib."""
    os.makedirs(out_dir, exist_ok=True)
    for name, model in trained_models.items():
        filename = name.lower().replace(" ", "_") + ".joblib"
        joblib.dump(model, os.path.join(out_dir, filename))
    print(f"Models saved to '{out_dir}/'")
