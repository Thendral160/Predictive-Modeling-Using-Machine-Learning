"""
Model Evaluation Module
-------------------------
Computes accuracy, precision, recall, F1-score, ROC-AUC, confusion matrices,
and full classification reports for trained models.
"""

import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    roc_auc_score,
    roc_curve,
    classification_report,
)


def evaluate_model(model, X_test, y_test):
    """Evaluate a single trained model.

    Returns:
        metrics (dict), confusion_matrix (np.ndarray),
        roc_data (tuple: fpr, tpr), classification_report (str)
    """
    y_pred = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1]

    metrics = {
        "Accuracy": accuracy_score(y_test, y_pred),
        "Precision": precision_score(y_test, y_pred),
        "Recall": recall_score(y_test, y_pred),
        "F1-Score": f1_score(y_test, y_pred),
        "ROC-AUC": roc_auc_score(y_test, y_proba),
    }

    cm = confusion_matrix(y_test, y_pred)
    fpr, tpr, _ = roc_curve(y_test, y_proba)
    report = classification_report(y_test, y_pred)

    return metrics, cm, (fpr, tpr), report


def evaluate_all(trained_models, X_test, y_test):
    """Evaluate all trained models.

    Returns:
        summary_df (pd.DataFrame): metrics table indexed by model name.
        results (dict): full per-model results (metrics, cm, roc_data, report).
    """
    results = {}
    summary_rows = []

    for name, model in trained_models.items():
        metrics, cm, roc_data, report = evaluate_model(model, X_test, y_test)
        results[name] = {
            "metrics": metrics,
            "confusion_matrix": cm,
            "roc_data": roc_data,
            "report": report,
        }
        row = {"Model": name}
        row.update(metrics)
        summary_rows.append(row)

    summary_df = pd.DataFrame(summary_rows).set_index("Model").round(4)
    return summary_df, results
