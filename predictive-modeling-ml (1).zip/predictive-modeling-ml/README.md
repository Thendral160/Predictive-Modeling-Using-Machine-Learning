# Predictive Modeling Using Machine Learning

A complete, end-to-end supervised learning pipeline that trains, evaluates, and compares multiple classification algorithms — **Logistic Regression, Decision Tree, and Random Forest** — to predict whether a tumor is malignant or benign from diagnostic measurements. Built as a hands-on internship project to demonstrate the core workflow of applied machine learning: data preprocessing, model training, evaluation, and visualization.

## Table of Contents

- [Overview](#overview)
- [Problem Statement](#problem-statement)
- [Dataset](#dataset)
- [Algorithms Used](#algorithms-used)
- [Project Structure](#project-structure)
- [Installation](#installation)
- [Usage](#usage)
- [Results](#results)
- [Visualizations](#visualizations)
- [Key Learnings](#key-learnings)
- [Future Improvements](#future-improvements)
- [Technologies Used](#technologies-used)
- [License](#license)

## Overview

This project builds a **binary classification system** that predicts patient outcomes (malignant vs. benign tumor diagnosis) based on a set of numerical features extracted from digitized images of breast mass cell nuclei. The pipeline covers the full supervised learning workflow:

1. **Data loading & preprocessing** — cleaning, train/test splitting, feature scaling
2. **Model training** — three different algorithms trained on the same data for fair comparison
3. **Model evaluation** — accuracy, precision, recall, F1-score, and ROC-AUC
4. **Visualization** — confusion matrices, ROC curves, and a side-by-side performance comparison chart

The goal is to practice the standard supervised learning workflow and understand how different algorithms trade off interpretability, accuracy, and robustness on the same problem.

## Problem Statement

Given a set of measurements describing the characteristics of cell nuclei present in a digitized image of a breast mass (radius, texture, perimeter, area, smoothness, etc.), predict whether the mass is **malignant (cancerous)** or **benign (non-cancerous)**.

This is a real-world style diagnostic prediction problem — the kind of binary classification task commonly encountered in healthcare analytics, risk scoring, and quality control systems.

## Dataset

**Source:** Breast Cancer Wisconsin (Diagnostic) Dataset — a well-known, publicly available dataset bundled directly with scikit-learn (`sklearn.datasets.load_breast_cancer`), so no external download is required.

| Property | Value |
|---|---|
| Samples | 569 |
| Features | 30 numeric features (e.g., mean radius, mean texture, mean perimeter, mean area, mean smoothness) |
| Target classes | 2 — Malignant (0), Benign (1) |
| Class balance | 212 malignant / 357 benign |
| Missing values | None |

A copy of the raw dataset is exported to `data/breast_cancer_data.csv` automatically when the pipeline runs, for transparency and reproducibility.

## Algorithms Used

| Algorithm | Type | Why it's included |
|---|---|---|
| **Logistic Regression** | Linear classifier | Fast, interpretable baseline; works well when classes are linearly separable |
| **Decision Tree** | Non-linear, rule-based | Easy to visualize and explain; captures non-linear relationships |
| **Random Forest** | Ensemble of trees | Reduces overfitting vs. a single tree; generally more robust and accurate |

All three models are trained on the **same** preprocessed train/test split so their performance can be compared fairly.

## Project Structure

```
predictive-modeling-ml/
├── data/
│   └── breast_cancer_data.csv          # Raw dataset (auto-generated on run)
├── models/
│   ├── logistic_regression.joblib      # Saved trained model
│   ├── decision_tree.joblib
│   └── random_forest.joblib
├── results/
│   ├── confusion_matrix_logistic_regression.png
│   ├── confusion_matrix_decision_tree.png
│   ├── confusion_matrix_random_forest.png
│   ├── roc_curve_comparison.png
│   ├── model_comparison.png
│   └── model_performance_summary.csv
├── src/
│   ├── __init__.py
│   ├── data_preprocessing.py           # Load, split, scale data
│   ├── models.py                       # Model definitions & training
│   ├── evaluate.py                     # Metrics, confusion matrix, ROC data
│   └── visualize.py                    # Plotting functions
├── main.py                             # Pipeline entry point
├── requirements.txt
├── .gitignore
├── LICENSE
└── README.md
```

## Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/<your-username>/predictive-modeling-ml.git
   cd predictive-modeling-ml
   ```

2. (Recommended) Create a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate      # On Windows: venv\Scripts\activate
   ```

3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Usage

Run the entire pipeline with a single command:

```bash
python main.py
```

This will:
- Load and save the dataset to `data/`
- Split and scale the data (80% train / 20% test, stratified)
- Train all three models
- Save trained models to `models/`
- Evaluate each model and print metrics + classification reports to the console
- Generate and save all visualizations to `results/`
- Save a metrics summary table to `results/model_performance_summary.csv`

Each module in `src/` can also be imported and used independently, e.g.:

```python
from src.data_preprocessing import load_data, split_and_scale
from src.models import get_models, train_models

df, target_names = load_data()
X_train, X_test, y_train, y_test, scaler, features = split_and_scale(df)

models = get_models()
trained = train_models(models, X_train, y_train)
```

## Results

Results from a sample run (80/20 stratified train/test split, `random_state=42`):

| Model | Accuracy | Precision | Recall | F1-Score | ROC-AUC |
|---|---|---|---|---|---|
| **Logistic Regression** | **0.9825** | 0.9861 | 0.9861 | 0.9861 | **0.9954** |
| Decision Tree | 0.9211 | 0.9565 | 0.9167 | 0.9362 | 0.9163 |
| Random Forest | 0.9561 | 0.9589 | 0.9722 | 0.9655 | 0.9937 |

**Best performing model: Logistic Regression**, with 98.25% test accuracy and a ROC-AUC of 0.9954 — indicating excellent separability between the two classes on this dataset. Random Forest was a close second and is generally the more robust choice on noisier, less linearly-separable real-world data.

*(Exact numbers will be regenerated each time `main.py` is run; results are deterministic given the fixed random seed.)*

## Visualizations

The pipeline automatically generates:

- **Confusion matrices** for each model — showing true vs. predicted classifications, useful for spotting false positives/negatives
- **ROC curve comparison** — overlaying all three models' true positive rate vs. false positive rate trade-offs, with AUC scores
- **Model comparison bar chart** — accuracy, precision, recall, F1, and ROC-AUC side-by-side across all models

All charts are saved as PNG files in `results/` and are ready to drop into a report or presentation.

## Key Learnings

- How to structure a clean, modular ML pipeline (separating data prep, modeling, evaluation, and visualization)
- Practical differences between a linear model, a single decision tree, and an ensemble method
- Why accuracy alone isn't enough — precision, recall, F1, and ROC-AUC each tell a different part of the story, especially for imbalanced or high-stakes classification problems
- How to read and interpret a confusion matrix and ROC curve
- The importance of feature scaling for distance/gradient-based algorithms like Logistic Regression

## Future Improvements

- Add hyperparameter tuning (GridSearchCV / RandomizedSearchCV) for each model
- Add k-fold cross-validation instead of a single train/test split
- Include feature importance plots (especially useful for Random Forest)
- Add a simple Streamlit/Flask web app for interactive predictions
- Extend to a regression variant (e.g., predicting a continuous target with true Linear Regression) to compare classification vs. regression workflows side by side

## Technologies Used

- **Python 3**
- **scikit-learn** — models, train/test split, scaling, metrics
- **pandas / numpy** — data handling
- **matplotlib / seaborn** — visualization
- **joblib** — model persistence

## License

This project is licensed under the MIT License — see the [LICENSE](LICENSE) file for details.

---

*Built as part of an internship project on predictive modeling and supervised learning.*
