"""
Predictive Modeling Using Machine Learning
=============================================
End-to-end pipeline: loads data, trains Logistic Regression, Decision Tree,
and Random Forest classifiers, evaluates them, and generates visualizations
(confusion matrices, ROC curves, performance comparison chart).

Usage:
    python main.py
"""

from src.data_preprocessing import load_data, save_raw_data, split_and_scale
from src.models import get_models, train_models, save_models
from src.evaluate import evaluate_all
from src.visualize import plot_confusion_matrix, plot_roc_curves, plot_model_comparison


def main():
    print("=" * 60)
    print("PREDICTIVE MODELING USING MACHINE LEARNING")
    print("Dataset: Breast Cancer Wisconsin (Diagnostic)")
    print("=" * 60)

    # 1. Load & save data
    df, target_names = load_data()
    save_raw_data(df)
    print(f"\nDataset shape: {df.shape}")
    print("Class distribution:")
    print(df["target"].value_counts().to_string())

    # 2. Preprocess
    X_train, X_test, y_train, y_test, scaler, feature_names = split_and_scale(df)
    print(f"\nTrain samples: {X_train.shape[0]} | Test samples: {X_test.shape[0]}")

    # 3. Train models
    print("\n--- Training Models ---")
    models = get_models()
    trained_models = train_models(models, X_train, y_train)
    save_models(trained_models)

    # 4. Evaluate models
    print("\n--- Evaluating Models ---")
    summary_df, results = evaluate_all(trained_models, X_test, y_test)
    print("\nModel Performance Summary:")
    print(summary_df.to_string())

    # 5. Visualizations
    print("\n--- Generating Visualizations ---")
    for name, data in results.items():
        fname = plot_confusion_matrix(data["confusion_matrix"], name, target_names)
        print(f"Saved: results/{fname}")

    plot_roc_curves(results)
    print("Saved: results/roc_curve_comparison.png")

    plot_model_comparison(summary_df)
    print("Saved: results/model_comparison.png")

    # 6. Detailed classification reports
    print("\n--- Detailed Classification Reports ---")
    for name, data in results.items():
        print(f"\n{name}:")
        print(data["report"])

    # 7. Save summary table
    summary_df.to_csv("results/model_performance_summary.csv")
    print("Saved: results/model_performance_summary.csv")

    print("\n" + "=" * 60)
    best_model = summary_df["Accuracy"].idxmax()
    print(
        f"Best performing model: {best_model} "
        f"(Accuracy = {summary_df.loc[best_model, 'Accuracy']:.4f})"
    )
    print("=" * 60)


if __name__ == "__main__":
    main()
